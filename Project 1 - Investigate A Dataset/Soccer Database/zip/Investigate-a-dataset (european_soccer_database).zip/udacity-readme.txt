I didn't see this quite early 
but I mentioned some sources in my markdown cells 
and here are few more from my web browser:

https://github.com/RaeezAhmedMoosa/udacity-da-investigate-a-dataset/blob/master/soccer-db-final.html
www.statology.org
sparkbyexamples.com
stackoverflow.com
classroom.udacity.com
www.youtube.com
www.geeksforgeeks.org
www.tutorialkart.com
www.tutorialspoint.com
www.w3schools.com